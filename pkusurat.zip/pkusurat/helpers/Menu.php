<?php
/**
 * Menu Items
 * All Project Menu
 * @category  Menu List
 */

class Menu{
	
	
			public static $navbartopleft = array(
		array(
			'path' => 'home', 
			'label' => 'Home', 
			'icon' => ''
		),
		
		array(
			'path' => 'surat_masuk', 
			'label' => 'Surat Masuk', 
			'icon' => '<i class="fa fa-download "></i>'
		),
		
		array(
			'path' => 'surat_keluar', 
			'label' => 'Surat Keluar', 
			'icon' => '<i class="fa fa-upload "></i>'
		),
		
		array(
			'path' => 'disposisi', 
			'label' => 'Disposisi', 
			'icon' => '<i class="fa fa-paper-plane-o "></i>'
		),
		
		array(
			'path' => 'unit', 
			'label' => 'Unit', 
			'icon' => '<i class="fa fa-th-large "></i>'
		),
		
		array(
			'path' => 'user', 
			'label' => 'User', 
			'icon' => ''
		)
	);
		
	
	
}