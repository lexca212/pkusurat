<?php
$comp_model = new SharedController;
$page_element_id = "edit-page-" . random_str();
$current_page = $this->set_current_page_link();
$csrf_token = Csrf::$token;
$data = $this->view_data;
//$rec_id = $data['__tableprimarykey'];
$page_id = $this->route->page_id;
$show_header = $this->show_header;
$view_title = $this->view_title;
$redirect_to = $this->redirect_to;
?>
<section class="page" id="<?php echo $page_element_id; ?>" data-page-type="edit"  data-display-type="" data-page-url="<?php print_link($current_page); ?>">
    <?php
    if( $show_header == true ){
    ?>
    <div  class="bg-light p-3 mb-3">
        <div class="container">
            <div class="row ">
                <div class="col ">
                    <h4 class="record-title">Edit  Disposisi</h4>
                </div>
            </div>
        </div>
    </div>
    <?php
    }
    ?>
    <div  class="">
        <div class="container">
            <div class="row ">
                <div class="col-md-7 comp-grid">
                    <?php $this :: display_page_errors(); ?>
                    <div  class="bg-light p-3 animated fadeIn page-content">
                        <form novalidate  id="" role="form" enctype="multipart/form-data"  class="form page-form form-horizontal needs-validation" action="<?php print_link("disposisi/edit/$page_id/?csrf_token=$csrf_token"); ?>" method="post">
                            <div>
                                <div class="form-group ">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <label class="control-label" for="surat_disposisi">Surat Dari <span class="text-danger">*</span></label>
                                        </div>
                                        <div class="col-sm-8">
                                            <div class="">
                                                <input id="ctrl-surat_disposisi"  value="<?php  echo $data['surat_disposisi']; ?>" type="text" placeholder="Enter Surat Dari" list="surat_disposisi_list"  required="" name="surat_disposisi"  class="form-control " />
                                                    <datalist id="surat_disposisi_list">
                                                        <?php 
                                                        $surat_disposisi_options = $comp_model -> disposisi_surat_disposisi_option_list();
                                                        if(!empty($surat_disposisi_options)){
                                                        foreach($surat_disposisi_options as $option){
                                                        $value = (!empty($option['value']) ? $option['value'] : null);
                                                        $label = (!empty($option['label']) ? $option['label'] : $value);
                                                        ?>
                                                        <option value="<?php echo $value; ?>"><?php echo $label; ?></option>
                                                        <?php
                                                        }
                                                        }
                                                        ?>
                                                    </datalist>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group ">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <label class="control-label" for="nosurat_disposisi">Nomor Surat <span class="text-danger">*</span></label>
                                            </div>
                                            <div class="col-sm-8">
                                                <div class="">
                                                    <input id="ctrl-nosurat_disposisi"  value="<?php  echo $data['nosurat_disposisi']; ?>" type="text" placeholder="Enter Nomor Surat" list="nosurat_disposisi_list"  required="" name="nosurat_disposisi"  class="form-control " />
                                                        <datalist id="nosurat_disposisi_list">
                                                            <?php 
                                                            $nosurat_disposisi_options = $comp_model -> disposisi_nosurat_disposisi_option_list();
                                                            if(!empty($nosurat_disposisi_options)){
                                                            foreach($nosurat_disposisi_options as $option){
                                                            $value = (!empty($option['value']) ? $option['value'] : null);
                                                            $label = (!empty($option['label']) ? $option['label'] : $value);
                                                            ?>
                                                            <option value="<?php echo $value; ?>"><?php echo $label; ?></option>
                                                            <?php
                                                            }
                                                            }
                                                            ?>
                                                        </datalist>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group ">
                                            <div class="row">
                                                <div class="col-sm-4">
                                                    <label class="control-label" for="perihal_disposisi">Perihal Disposisi <span class="text-danger">*</span></label>
                                                </div>
                                                <div class="col-sm-8">
                                                    <div class="">
                                                        <input id="ctrl-perihal_disposisi"  value="<?php  echo $data['perihal_disposisi']; ?>" type="text" placeholder="Enter Perihal Disposisi" list="perihal_disposisi_list"  required="" name="perihal_disposisi"  class="form-control " />
                                                            <datalist id="perihal_disposisi_list">
                                                                <?php 
                                                                $perihal_disposisi_options = $comp_model -> disposisi_perihal_disposisi_option_list();
                                                                if(!empty($perihal_disposisi_options)){
                                                                foreach($perihal_disposisi_options as $option){
                                                                $value = (!empty($option['value']) ? $option['value'] : null);
                                                                $label = (!empty($option['label']) ? $option['label'] : $value);
                                                                ?>
                                                                <option value="<?php echo $value; ?>"><?php echo $label; ?></option>
                                                                <?php
                                                                }
                                                                }
                                                                ?>
                                                            </datalist>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group ">
                                                <div class="row">
                                                    <div class="col-sm-4">
                                                        <label class="control-label" for="unit_disposisi">Unit Disposisi <span class="text-danger">*</span></label>
                                                    </div>
                                                    <div class="col-sm-8">
                                                        <div class="">
                                                            <select required=""  id="ctrl-unit_disposisi" name="unit_disposisi[]"  placeholder="Select a value ..." multiple data-max-items="5"  class="selectize" >
                                                                <?php
                                                                $selected_options = explode(",", $data['unit_disposisi']);
                                                                foreach($selected_options as $option){
                                                                ?>
                                                                <option selected><?php echo $option; ?></option>
                                                                <?php
                                                                }
                                                                ?>
                                                                <?php
                                                                $rec = $data['unit_disposisi'];
                                                                $unit_disposisi_options = $comp_model -> disposisi_unit_disposisi_option_list();
                                                                if(!empty($unit_disposisi_options)){
                                                                foreach($unit_disposisi_options as $option){
                                                                $value = (!empty($option['value']) ? $option['value'] : null);
                                                                $label = (!empty($option['label']) ? $option['label'] : $value);
                                                                $selected = ( $value == $rec ? 'selected' : null );
                                                                ?>
                                                                <option 
                                                                    <?php echo $selected; ?> value="<?php echo $value; ?>"><?php echo $label; ?>
                                                                </option>
                                                                <?php
                                                                }
                                                                }
                                                                ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group ">
                                                <div class="row">
                                                    <div class="col-sm-4">
                                                        <label class="control-label" for="tanggal_disposisi">Tanggal Disposisi <span class="text-danger">*</span></label>
                                                    </div>
                                                    <div class="col-sm-8">
                                                        <div class="input-group">
                                                            <input id="ctrl-tanggal_disposisi" class="form-control datepicker  datepicker"  required="" value="<?php  echo $data['tanggal_disposisi']; ?>" type="datetime" name="tanggal_disposisi" placeholder="Enter Tanggal Disposisi" data-enable-time="false" data-min-date="" data-max-date="" data-date-format="Y-m-d" data-alt-format="d-m-Y" data-inline="false" data-no-calendar="false" data-mode="single" />
                                                                <div class="input-group-append">
                                                                    <span class="input-group-text"><i class="fa fa-calendar"></i></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group ">
                                                    <div class="row">
                                                        <div class="col-sm-4">
                                                            <label class="control-label" for="isi_disposisi">Isi Disposisi <span class="text-danger">*</span></label>
                                                        </div>
                                                        <div class="col-sm-8">
                                                            <div class="">
                                                                <textarea placeholder="Enter Isi Disposisi" id="ctrl-isi_disposisi"  required="" rows="5" name="isi_disposisi" class=" form-control"><?php  echo $data['isi_disposisi']; ?></textarea>
                                                                <!--<div class="invalid-feedback animated bounceIn text-center">Please enter text</div>-->
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-ajax-status"></div>
                                            <div class="form-group text-center">
                                                <button class="btn btn-primary" type="submit">
                                                    Update
                                                    <i class="fa fa-send"></i>
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
