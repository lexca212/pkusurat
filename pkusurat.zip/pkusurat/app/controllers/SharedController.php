<?php 

/**
 * SharedController Controller
 * @category  Controller / Model
 */
class SharedController extends BaseController{
	
	/**
     * disposisi_surat_disposisi_option_list Model Action
     * @return array
     */
	function disposisi_surat_disposisi_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT pengirim_surat_masuk AS value,pengirim_surat_masuk AS label FROM surat_masuk ORDER BY id_surat_masuk ASC";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * disposisi_nosurat_disposisi_option_list Model Action
     * @return array
     */
	function disposisi_nosurat_disposisi_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT nomer_surat_masuk AS value,nomer_surat_masuk AS label FROM surat_masuk ORDER BY id_surat_masuk";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * disposisi_unit_disposisi_option_list Model Action
     * @return array
     */
	function disposisi_unit_disposisi_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT nama_unit AS value,nama_unit AS label FROM unit";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * disposisi_perihal_disposisi_option_list Model Action
     * @return array
     */
	function disposisi_perihal_disposisi_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT perihal_surat_masuk AS value,perihal_surat_masuk AS label FROM surat_masuk";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * user_username_value_exist Model Action
     * @return array
     */
	function user_username_value_exist($val){
		$db = $this->GetModel();
		$db->where("username", $val);
		$exist = $db->has("user");
		return $exist;
	}

	/**
     * user_email_value_exist Model Action
     * @return array
     */
	function user_email_value_exist($val){
		$db = $this->GetModel();
		$db->where("email", $val);
		$exist = $db->has("user");
		return $exist;
	}

	/**
     * getcount_suratmasuk Model Action
     * @return Value
     */
	function getcount_suratmasuk(){
		$db = $this->GetModel();
		$sqltext = "SELECT COUNT(*) AS num FROM surat_masuk";
		$queryparams = null;
		$val = $db->rawQueryValue($sqltext, $queryparams);
		
		if(is_array($val)){
			return $val[0];
		}
		return $val;
	}

	/**
     * getcount_disposisi Model Action
     * @return Value
     */
	function getcount_disposisi(){
		$db = $this->GetModel();
		$sqltext = "SELECT COUNT(*) AS num FROM disposisi";
		$queryparams = null;
		$val = $db->rawQueryValue($sqltext, $queryparams);
		
		if(is_array($val)){
			return $val[0];
		}
		return $val;
	}

	/**
     * getcount_suratkeluar Model Action
     * @return Value
     */
	function getcount_suratkeluar(){
		$db = $this->GetModel();
		$sqltext = "SELECT COUNT(*) AS num FROM surat_keluar";
		$queryparams = null;
		$val = $db->rawQueryValue($sqltext, $queryparams);
		
		if(is_array($val)){
			return $val[0];
		}
		return $val;
	}

}
